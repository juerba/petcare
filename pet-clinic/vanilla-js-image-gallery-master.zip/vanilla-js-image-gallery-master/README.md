# Image Gallery with Vanilla JS

This quick and easy image gallery uses only JS(ES6) and CSS to power functionality and animation.
